# Tips! 2.0
Working on a revised copy of a my Tips calculator. 

Time spent: 1.5 hours in total

Completed user stories:

* Required: A tip calculator that works. :)
* Optional: Changed colors and fonts for the views.
* Optional: App icon and launch image.
* Optional: Experimented around with auto-layout and constraints.


Notes:
Spent some time exploring auto-layout and constraints, so this will work on multiple device sizes. Also added support for splitting the tip between multiple people.
